"""Rotate and flip tool."""
