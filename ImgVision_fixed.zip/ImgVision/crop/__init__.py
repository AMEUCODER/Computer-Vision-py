"""Crop tool."""
